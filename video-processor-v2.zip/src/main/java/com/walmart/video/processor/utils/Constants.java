package com.walmart.video.processor.utils;

import java.util.Arrays;
import java.util.List;

public class Constants {

    public final static List<String> INVENTORY = Arrays.asList("mouse", "headphone", "computer", "laptop", "mobile", "keyboard", "mac", "dell", "hp", "microsoft",
            "kitchen", "mug", "cup", "bottle", "painting");
}

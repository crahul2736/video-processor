package com.walmart.video.processor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walmart.video.processor.model.ProductDetails;
import com.walmart.video.processor.utils.DirUtil;

import java.net.InetAddress;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Collectors;

public class Main {

    public static void main(String[] args) throws Exception {

        String json = "{\n" +
                "\"productDetails\": [\n" +
                "{\n" +
                "\"productName\": \"computer keyboard\",\n" +
                "\"dominantColor\": \"Black\",\n" +
                "\"confidence\": 0.45624473690986633,\n" +
                "\"tag\": \"mac\",\n" +
                "\"brand\": null,\n" +
                "\"imgUrl\": \"http://192.168.29.37:8080/images/cropped/computer keyboard-1652932518859.png\"\n" +
                "},\n" +
                "{\n" +
                "\"productName\": \"computer keyboard\",\n" +
                "\"dominantColor\": \"Black\",\n" +
                "\"confidence\": 0.4935857057571411,\n" +
                "\"tag\": \"mac\",\n" +
                "\"brand\": null,\n" +
                "\"imgUrl\": \"http://192.168.29.37:8080/images/cropped/computer keyboard-1652932519126.png\"\n" +
                "},\n" +
                "{\n" +
                "\"productName\": \"computer keyboard\",\n" +
                "\"dominantColor\": \"Black\",\n" +
                "\"confidence\": 0.44888806343078613,\n" +
                "\"tag\": \"mac\",\n" +
                "\"brand\": null,\n" +
                "\"imgUrl\": \"http://192.168.29.37:8080/images/cropped/computer keyboard-1652932519362.png\"\n" +
                "},\n" +
                "{\n" +
                "\"productName\": \"computer keyboard\",\n" +
                "\"dominantColor\": \"Black\",\n" +
                "\"confidence\": 0.4735924303531647,\n" +
                "\"tag\": \"mac\",\n" +
                "\"brand\": null,\n" +
                "\"imgUrl\": \"http://192.168.29.37:8080/images/cropped/computer keyboard-1652932519613.png\"\n" +
                "},\n" +
                "{\n" +
                "\"productName\": \"computer keyboard\",\n" +
                "\"dominantColor\": \"Black\",\n" +
                "\"confidence\": 0.40381893515586853,\n" +
                "\"tag\": \"mac\",\n" +
                "\"brand\": null,\n" +
                "\"imgUrl\": \"http://192.168.29.37:8080/images/cropped/computer keyboard-1652932519863.png\"\n" +
                "},\n" +
                "{\n" +
                "\"productName\": \"computer mouse\",\n" +
                "\"dominantColor\": \"Black\",\n" +
                "\"confidence\": 0.9366539120674133,\n" +
                "\"tag\": \"mouse\",\n" +
                "\"brand\": null,\n" +
                "\"imgUrl\": \"http://192.168.29.37:8080/images/cropped/computer mouse-1652932518945.png\"\n" +
                "},\n" +
                "{\n" +
                "\"productName\": \"computer mouse\",\n" +
                "\"dominantColor\": \"Black\",\n" +
                "\"confidence\": 0.9263395071029663,\n" +
                "\"tag\": \"mouse\",\n" +
                "\"brand\": null,\n" +
                "\"imgUrl\": \"http://192.168.29.37:8080/images/cropped/computer mouse-1652932519189.png\"\n" +
                "},\n" +
                "{\n" +
                "\"productName\": \"computer mouse\",\n" +
                "\"dominantColor\": \"Black\",\n" +
                "\"confidence\": 0.9347368478775024,\n" +
                "\"tag\": \"mouse\",\n" +
                "\"brand\": null,\n" +
                "\"imgUrl\": \"http://192.168.29.37:8080/images/cropped/computer mouse-1652932519440.png\"\n" +
                "},\n" +
                "{\n" +
                "\"productName\": \"computer mouse\",\n" +
                "\"dominantColor\": \"Black\",\n" +
                "\"confidence\": 0.9486278295516968,\n" +
                "\"tag\": \"mouse\",\n" +
                "\"brand\": null,\n" +
                "\"imgUrl\": \"http://192.168.29.37:8080/images/cropped/computer mouse-1652932519676.png\"\n" +
                "},\n" +
                "{\n" +
                "\"productName\": \"computer mouse\",\n" +
                "\"dominantColor\": \"Black\",\n" +
                "\"confidence\": 0.9426681995391846,\n" +
                "\"tag\": \"mouse\",\n" +
                "\"brand\": null,\n" +
                "\"imgUrl\": \"http://192.168.29.37:8080/images/cropped/computer mouse-1652932519926.png\"\n" +
                "},\n" +
                "{\n" +
                "\"productName\": \"Laptop\",\n" +
                "\"dominantColor\": \"Black\",\n" +
                "\"confidence\": 0.722030758857727,\n" +
                "\"tag\": \"mac\",\n" +
                "\"brand\": null,\n" +
                "\"imgUrl\": \"http://192.168.29.37:8080/images/cropped/Laptop-1652932519001.png\"\n" +
                "},\n" +
                "{\n" +
                "\"productName\": \"Laptop\",\n" +
                "\"dominantColor\": \"Black\",\n" +
                "\"confidence\": 0.684560239315033,\n" +
                "\"tag\": \"mac\",\n" +
                "\"brand\": null,\n" +
                "\"imgUrl\": \"http://192.168.29.37:8080/images/cropped/Laptop-1652932519252.png\"\n" +
                "},\n" +
                "{\n" +
                "\"productName\": \"Laptop\",\n" +
                "\"dominantColor\": \"Black\",\n" +
                "\"confidence\": 0.718392014503479,\n" +
                "\"tag\": \"mac\",\n" +
                "\"brand\": null,\n" +
                "\"imgUrl\": \"http://192.168.29.37:8080/images/cropped/Laptop-1652932519503.png\"\n" +
                "},\n" +
                "{\n" +
                "\"productName\": \"Laptop\",\n" +
                "\"dominantColor\": \"Black\",\n" +
                "\"confidence\": 0.7302590608596802,\n" +
                "\"tag\": \"mac\",\n" +
                "\"brand\": null,\n" +
                "\"imgUrl\": \"http://192.168.29.37:8080/images/cropped/Laptop-1652932519754.png\"\n" +
                "},\n" +
                "{\n" +
                "\"productName\": \"Laptop\",\n" +
                "\"dominantColor\": \"Black\",\n" +
                "\"confidence\": 0.6921813488006592,\n" +
                "\"tag\": \"mac\",\n" +
                "\"brand\": null,\n" +
                "\"imgUrl\": \"http://192.168.29.37:8080/images/cropped/Laptop-1652932520004.png\"\n" +
                "}\n" +
                "]\n" +
                "}";


        ObjectMapper om = new ObjectMapper();

      List<ProductDetails> productDetailsLst =   om.readValue(json, ArrayList.class);
        List<ProductDetails> uniqueProducts = productDetailsLst.stream()
                .collect(Collectors.groupingBy(ProductDetails::getTag,
                        Collectors.maxBy(Comparator.comparing(ProductDetails::getConfidence))))
                .values()
                .stream()
                .map(Optional::get)
                .collect(Collectors.toList());
        uniqueProducts.forEach(System.out::println);

    }
}

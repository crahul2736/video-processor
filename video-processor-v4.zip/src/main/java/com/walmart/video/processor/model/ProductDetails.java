package com.walmart.video.processor.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@AllArgsConstructor
@Data
@Builder
public class ProductDetails  implements Serializable {
    private String Product;
    private String Color;
    private double Confidence;
    private String Tag;
    private String Brand;
    private String Image;
}
